import pandas as pd
import folium


import statsmodels.api as sm
import statsmodels.tsa.stattools as ts
import matplotlib.pyplot as plt


plt.style.use('fivethirtyeight')
plt.rcParams.update({'font.size': 10})

rodent_df = pd.read_csv("../data/rodent_inspection_clean.csv")
rodent_df.replace(0, float('NaN'), inplace=True)
rodent_df.dropna(subset = ["LATITUDE","LONGITUDE"], inplace=True)
rodent_df = rodent_df.round({"LATITUDE":2, "LONGITUDE":2})
rodent_df['INSPECTION_DATE'] = pd.to_datetime(rodent_df['INSPECTION_DATE'])
rodent_df['YEAR'] = pd.DatetimeIndex(rodent_df['INSPECTION_DATE']).year

rodent_df['ID'] = rodent_df.index
rodent_df['MONTH'] = pd.DatetimeIndex(rodent_df['INSPECTION_DATE']).month
rodent_df['YEAR_MONTH'] = rodent_df['YEAR'].astype(str)+'/'+rodent_df['MONTH'].astype(str).str.zfill(2)

monthly_data =  rodent_df.groupby(['YEAR_MONTH'], as_index=False)['ID'].count()
monthly_data = monthly_data[monthly_data['YEAR_MONTH'].str.slice(stop=4).astype(int)>2008 ]
monthly_data = monthly_data[monthly_data['YEAR_MONTH'].str.slice(stop=4).astype(int)<2019 ]
monthly_data = monthly_data[monthly_data['ID'].astype(int)>500 ]
monthly_data.index = pd.to_datetime(monthly_data['YEAR_MONTH'], format='%Y/%m')
monthly_data.drop(['YEAR_MONTH'], axis=1,inplace = True)


plt.plot(monthly_data.ID, label='Occurrences',linewidth=1.5)
plt.title('Rodent Incidents from 2009-2019')
plt.xlabel('Years')
plt.legend()
plt.show()

monthly_data.ID.rolling(12).mean().plot(figsize=(20,10), linewidth=5, fontsize=20)
plt.show()

# plt.plot(monthly_data, color='blue', label='Occurrences of Rodents',linewidth=1.5)
# plt.plot(monthly_data.rolling(window=12,center=False).mean(), color='red',label='Mean',linewidth=2)
# plt.plot(monthly_data.rolling(window=12,center=False).std(),color='green',label='Standard Deviation',linewidth=2)
# plt.title('Frequency, Rolling Mean & Standard Deviation')
# plt.figure(figsize=(20,10))
# plt.show()

# multiplicative
result = sm.tsa.seasonal_decompose(monthly_data.ID, model='additive', period=12)
result.plot()
plt.show()


pd.plotting.autocorrelation_plot(monthly_data.ID)
plt.show()

pd.plotting.lag_plot(monthly_data.ID)
plt.show()




# def test_adf(series, title=''):
#     dfout={}
#     dftest=sm.tsa.adfuller(series.dropna(), autolag='AIC', regression='ct')
#     for key,val in dftest[4].items():
#         dfout[f'critical value ({key})']=val
#     print(dftest)
#     if dftest[1]<=0.05:
#         print("Strong evidence against Null Hypothesis")
#         print("Reject Null Hypothesis - Data is Stationary")
#         print("Data is Stationary", title)
#     else:
#         print("Strong evidence for  Null Hypothesis")
#         print("Accept Null Hypothesis - Data is not Stationary")
#         print("Data is NOT Stationary for", title)
# test_adf(monthly_data.ID, " Stock Price")




# fig,ax = plt.subplots(2,1,figsize=(20,10))
# fig = sm.graphics.tsa.plot_acf(tra.diff().dropna(), lags=50, ax=ax[0])
# fig = sm.graphics.tsa.plot_pacf(tra.diff().dropna(), lags=50, ax=ax[1])
# plt.show()

mod = sm.tsa.SARIMAX(monthly_data.ID, trend='n', order=(3,1,3), seasonal_order=(1,1,1,12))
results = mod.fit()
print(results.summary())


monthly_data['forecast'] = results.predict(start = 80, end= 120, dynamic= True)  
monthly_data[['ID', 'forecast']].plot(figsize=(12, 8))
plt.show()

def forcasting_future_months(df, no_of_months):
    print(df.head())
    df_perdict = df.reset_index()
    mon = df_perdict['YEAR_MONTH']
    mon = mon + pd.DateOffset(months = no_of_months)
    future_dates = mon[-no_of_months -1:]
    df_perdict = df_perdict.set_index('YEAR_MONTH')
    future = pd.DataFrame(index=future_dates, columns= df_perdict.columns)
    df_perdict = pd.concat([df_perdict, future])
    df_perdict['forecast'] = results.predict(start = 113, end = 160, dynamic= True)  
    df_perdict[['ID', 'forecast']].iloc[-no_of_months - 120:].plot(figsize=(12, 8))
    plt.show()
    return df_perdict[-no_of_months:]

predicted = forcasting_future_months(monthly_data.ID,24)
# from statsmodels.tsa.arima_model import ARIMA

# model = ARIMA(monthly_data.values.reshape(-1).tolist(), order=(2,1,2))
# results_ARIMA = model.fit(disp=-1)
# plt.plot(results_ARIMA.fittedvalues, color='red')
# print('Plotting ARIMA model')
